package edu.mum.cs544.bank.jms;

public interface IJMSSender {
	public void sendJMSMessage (String text);
}
