package edu.mum.cs544.bank.logging;

public interface ILogger {
    public void log(String logstring);
}
