package com.paypal.base;

public class HttpStatusCodes {
	
	public static final int BAD_REQUEST = 400;
	
}
