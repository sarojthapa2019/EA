package edu.mum.cs544;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.time.LocalDate;
import java.util.List;

public class AppBook {

    private static EntityManagerFactory emf;

    public static void main(String[] args) throws Exception {
        emf = Persistence.createEntityManagerFactory("cs544");

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        // Create new instance of Book and set values in it
        Book b1 = new Book("Spring Beginner", "000-111-2222","Annual", 35, LocalDate.now());
        // save the Book
        em.persist(b1);
        // Create new instance of Book and set values in it
        Book b2 = new Book("Spring Beginner2", "111-111-2222","Annual2", 55, LocalDate.now());
        // save the Book
        em.persist(b2);

        Book b3 = new Book("Spring Beginner3", "333-111-2222","Annual3", 65, LocalDate.now());
        em.persist(b3);
        em.getTransaction().commit();
        em.close();


        em = emf.createEntityManager();
        em.getTransaction().begin();
        // retieve all books
        TypedQuery<Book> query = em.createQuery("from Book", Book.class);
        List<Book> books = query.getResultList();
        for (Book book : books) {
            System.out.println(book);
        }
        em.getTransaction().commit();
        em.close();


        em = emf.createEntityManager();
        em.getTransaction().begin();
        // retieve all books
        List<Book> bookList = em.createQuery("from Book", Book.class).getResultList();

        Book book = bookList.get(0);
        book.setAuthor("Tina");
        em.persist(book);

        em.remove(bookList.get(1));

        em.getTransaction().commit();
        em.close();


        em = emf.createEntityManager();
        em.getTransaction().begin();
        // retieve all books
        em.createQuery("from Book", Book.class).getResultList().forEach(System.out::println);

        em.getTransaction().commit();
        em.close();
    }
}
