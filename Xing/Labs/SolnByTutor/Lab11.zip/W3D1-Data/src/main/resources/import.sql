INSERT INTO Book VALUES(NULL, 'ISBN1', 'Author1', 5.5, 'title1');
INSERT INTO Book VALUES(NULL, 'ISBN2', 'Author2', 10.10, 'title1');