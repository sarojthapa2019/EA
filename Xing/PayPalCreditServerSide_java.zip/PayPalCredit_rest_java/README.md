# PayPal Credit Demo using REST API with Checkout.js v4
Servlet Web Application showcasing PayPal Credit with REST API using Checkout.js v4

### Quick Set up and run

1) Locate the ppcredit.war file in the dist folder.
2) Copy the war file and deploy in your Apache Tomcat webapps folder.
3) Opening localhost:8080/ppcredit in your browser will fire the html page.


### Eclipse Setup

Clone the repository to your local machine

Open Eclipse -> File -> Import -> General -> Existing projects to into workspace

Browse the location of the project - Finish the import

Add Apache Tomcat to Project Facets Runtime 

##### Jars Needed

> commons-codec-1.7.jar (Libs for handling encoder, decoder)

> json-20140107.jar (Helper for handling Json)

> okhttp-3.9.0.jar (Http request)

> okio-1.13.0.jar (Http request)

The above jars are available in lib folder under WebContent -> WEB-INF -> lib

##### Build path

1) Add the above jars to your java built path (Right click the project in eclipse choose properties -> Java Build Path -> Add Jars -> Select the current project, browse to lib folder select all the jars and complete the process)
2) Add the appropriate Java Runtime Environment to your build path
3) Add Apache Tomcat to your build path

##### Run

1) Configure Apache Tomcat on your eclipse
2) Right click the project Run As -> Run on Server.
3) Open the below URL in browser

>http://localhost:8080/{code_folder_name}/


##### Flow

Clicking on PayPal Credit button will start the PayPal Credit flow.


##### App Configuration 

Application configuration is configured in 'application.properties' file found in WEB-INF - > application.properties file

Change the configuration according to your REST app (Client Id, Secret) to try out your REST app credentials.

Setting 'IS_APPLICATION_IN_SANDBOX' field in application.properties file to 'true' will run the app in sandbox environment and 'false' will run in LIVE environment.

##### Package Explanation

>com.paypal.demo.dto - Holds DTO classes to generate the payload needed for create payments API call.

>com.paypal.demo.helpers - Holds Helper class to map values from HTML to DTO and to generate random invoice no, methods to invoke API calls (post, get, getAccessToken, API invocation methods)

>com.paypal.demo.servlets - Servlets to make API calls to PayPal server

HTML files are placed in WebContent folder

Note: Use TLSv1.2 as in given code to avoid SSL handshake failures.
